<link href="vendor/wow-master/css/libs/animate.css" rel="stylesheet">
<link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
<link rel="stylesheet" href="vendor/bootstrap-select-country/css/bootstrap-select-country.min.css">
<link rel="stylesheet" href="vendor/jquery-nice-select/css/nice-select.css">
<link href="vendor/datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">

<link href="vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
<!--swiper-slider-->
<link rel="stylesheet" href="vendor/swiper/css/swiper-bundle.min.css">
<!-- Style css -->
<link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">