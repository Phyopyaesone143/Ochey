<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include('../css.php'); ?>
</head>

<body>
    <?php include('../loader.php'); ?>
    <div id="main-wrapper" class="wallet-open active">
        <?php include('../header.php'); ?>
        <?php include('../navheader.php') ?>
        <?php include('../sidebar.php'); ?>
    </div>
    <h1>Hello Users</h1>
    <?php include('../js.php'); ?>
</body>

</html>