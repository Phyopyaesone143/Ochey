<!-- closer btn  -->

<div id="closer" class="ri-close-line"></div>

<!-- navbar start  -->

<nav class="navbar">
    <a href="index.php">home</a>
    <a href="shop.php">shop</a>
    <a href="about.php">about</a>
    <a href="team.php">team</a>
    <a href="blog.php">blog</a>
    <a href="contact.php">contact</a>
</nav>

<!-- navbar end  -->